//Models
const { Meal } = require('../models/meal.model');

//utlis
const { catchAsync } = require('../utils/catchAsync');
const { AppError } = require('../utils/appError');

dotenv.config({ path: './config.env' });

