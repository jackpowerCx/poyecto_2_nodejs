const express = require('express');

// Middlewares

// Controller


module.exports = { mealsRouter: router };