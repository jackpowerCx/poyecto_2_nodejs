const express = require('express');

// Middlewares
const { restaurantExists } = require('../middlewares/restaurants.middlewares')
//controller
const {
    createRestaurants,
    getAllRestaurants,
    updateRestaurant,
    deleteRestaurant,
    getRestaurantsById,
} = require('../controllers/restaurants.controller');

const router = express.Router();

router
    .route('/')
    .post(createRestaurants)
    .get(getAllRestaurants);

router
    .route('/:id')
    .get(restaurantExists, getRestaurantsById)
    .patch(restaurantExists, updateRestaurant)
    .delete(restaurantExists, deleteRestaurant);

module.exports = { restaurantsRouter: router };